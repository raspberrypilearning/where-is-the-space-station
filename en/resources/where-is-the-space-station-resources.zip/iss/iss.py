#!/bin/python3

import json
import turtle
import urllib.request

